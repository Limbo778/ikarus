// Реэкспортируем типы из общей схемы
export { 
  User,
  Conference,
  Subscription,
  Payment,
  Participant,
  ChatMessage,
  Poll,
  PollOption
} from '@shared/schema';